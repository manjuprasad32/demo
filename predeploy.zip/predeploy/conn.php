<?php
$dbhost="localhost";
$dbusername="root";
$dbpassword=""; // Enter your mysql password here
$dbname="fullstack";  // enter the database which u have created 

$conn=mysqli_connect($dbhost,$dbusername,$dbpassword,$dbname);
if(!$conn)
{
	die("connection failed:".mysqli_connect_error());
}
else
{
	echo"connected to database";
}

?>




